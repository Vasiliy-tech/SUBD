#!/usr/bin/env bash
java -jar Game-1.0-jar-with-dependencies.jar
